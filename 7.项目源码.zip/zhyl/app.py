import serial
import time
from flask import Flask, render_template, request, send_file, jsonify
from analyzer import RKLLMHealthAnalyzer  # 确保这个模块存在且正确实现
from io import BytesIO
from xhtml2pdf import pisa
import os
import logging
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from werkzeug.utils import secure_filename

app = Flask(__name__)
app.secret_key = 'your_secret_key'

# 初始化健康分析器
health_analyzer = RKLLMHealthAnalyzer()

# 配置上传文件的目录和允许的扩展名
UPLOAD_FOLDER = os.path.join(app.root_path, 'uploads')
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
app.config['MAX_CONTENT_LENGTH'] = 5 * 1024 * 1024  # 最大上传大小为5MB

# 允许上传的图片扩展名
ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'gif'}

def allowed_file(filename):
    """检查文件扩展名是否被允许"""
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

# 注册支持中文的字体
font_path = os.path.abspath(os.path.join(app.root_path, 'fonts', 'SimHei.ttf'))
if os.path.exists(font_path):
    try:
        pdfmetrics.registerFont(TTFont('NotoSansCJK', font_path))
        print("字体注册成功！")
    except Exception as e:
        print(f"字体注册失败: {e}")
else:
    print(f"字体文件未找到: {font_path}")

def resolve_uri(uri, rel=None):
    """将 URI 转换为 xhtml2pdf 可识别的绝对路径"""
    if uri.startswith('static/'):
        return os.path.join(app.root_path, uri)
    elif uri.startswith('uploads/'):
        return os.path.join(app.root_path, uri)
    return uri

@app.route('/', methods=['GET'])
def index():
    return render_template('index.html')

@app.route('/analyze', methods=['POST'])
def analyze():
    """处理 AJAX 请求，返回 JSON 格式的分析结果"""
    data = request.get_json()
    if not data:
        return jsonify({'status': 'error', 'message': '无效的数据。'}), 400

    try:
        spo2 = float(data.get('spo2', 0))
        heart_rate = float(data.get('heart_rate', 0))
        temperature = float(data.get('temperature', 0))
    except ValueError:
        return jsonify({'status': 'error', 'message': '请输入有效的数字！'}), 400

    health_data = {
        "spo2": spo2,
        "heart_rate": heart_rate,
        "temperature": temperature
    }

    # 分析健康数据
    result = health_analyzer.analyze_health_data(health_data)

    return jsonify({
        'status': 'success',
        'result': result,
        'data': health_data
    })

@app.route('/export_pdf', methods=['POST'])
def export_pdf():
    """将分析结果导出为 PDF"""
    try:
        # 获取表单数据
        name = request.form.get('name').strip()
        age = request.form.get('age').strip()
        spo2 = request.form.get('spo2')
        heart_rate = request.form.get('heart_rate')
        temperature = request.form.get('temperature')
        result = request.form.get('result')
        
        # 获取上传的照片
        if 'photo' not in request.files:
            return jsonify({'status': 'error', 'message': '未上传照片。'}), 400
        
        photo = request.files['photo']
        if photo.filename == '':
            return jsonify({'status': 'error', 'message': '未选择照片。'}), 400
        if photo and allowed_file(photo.filename):
            filename = secure_filename(photo.filename)
            photo_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
            photo.save(photo_path)
        else:
            return jsonify({'status': 'error', 'message': '不支持的文件类型。'}), 400

        if not all([name, age, spo2, heart_rate, temperature, result, photo_path]):
            return jsonify({'status': 'error', 'message': '缺少必要的数据来生成 PDF。'}), 400

        # 渲染 PDF 模板
        rendered = render_template('pdf_template.html',
                                   name=name,
                                   age=age,
                                   spo2=spo2,
                                   heart_rate=heart_rate,
                                   temperature=temperature,
                                   result=result,
                                   photo_url=os.path.join('uploads', filename))

        # 创建 PDF
        pdf = BytesIO()
        pisa_status = pisa.CreatePDF(
            src=rendered,
            dest=pdf,
            encoding='UTF-8',
            link_callback=resolve_uri
        )

        if pisa_status.err:
            return jsonify({'status': 'error', 'message': '生成 PDF 失败。'}), 500

        pdf.seek(0)
        filename_pdf = f"health_analysis_{name}_{age}.pdf"
        response = send_file(pdf, download_name=filename_pdf, as_attachment=True)

        # 删除上传的照片（可选）
        os.remove(photo_path)

        return response

    except Exception as e:
        return jsonify({'status': 'error', 'message': f'生成 PDF 时发生错误: {str(e)}'}), 500

@app.route('/shutdown', methods=['GET'])
def shutdown():
    """关闭应用"""
    func = request.environ.get('werkzeug.server.shutdown')
    if func:
        func()
    return '服务器正在关闭...'

@app.route('/get_heart_rate_and_blood_oxygen', methods=['GET'])
def get_heart_rate_and_blood_oxygen():
    """获取心率和血氧数据"""
    try:
        # 打开串口
        ser = serial.Serial('/dev/ttyACM0', 115200, timeout=1)
        
        # 发送命令以获取心率和血氧
        ser.write(b'#')
        time.sleep(10)  # 等待数据传输
        
        # 读取返回的数据
        hr_bo_data = ser.readline().decode().strip()
        print(hr_bo_data)  # 打印调试信息

        # 关闭串口
        ser.close()

        # 解析数据
        hr_bo_values = hr_bo_data.split(',')
        heart_rate = hr_bo_values[0].split(':')[1].strip() if len(hr_bo_values) > 0 and ':' in hr_bo_values[0] else 'N/A'
        blood_oxygen = hr_bo_values[1].split(':')[1].strip() if len(hr_bo_values) > 1 and ':' in hr_bo_values[1] else 'N/A'

        return jsonify({
            'status': 'success',
            'heart_rate': heart_rate,
            'blood_oxygen': blood_oxygen
        })

    except Exception as e:
        return jsonify({'status': 'error', 'message': str(e)}), 500


@app.route('/get_temperature', methods=['GET'])
def get_temperature():
    """获取温度数据"""
    try:
        print('ok')  # 打印调试信息
        # 打开串口
        ser = serial.Serial('/dev/ttyACM0', 115200, timeout=1)
        print('ok')  # 打印调试信息
        # 发送命令以获取温度
        ser.write(b'@')
        time.sleep(56)  # 等待数据传输
        
        # 读取返回的数据
        temperature_data = ser.readline().decode().strip()
        print(temperature_data)  # 打印调试信息

        # 关闭串口
        ser.close()

        # 解析温度数据
        temperature_value = temperature_data.split(':')[1].strip() if ':' in temperature_data else 'N/A'

        return jsonify({
            'status': 'success',
            'temperature': temperature_value
        })

    except Exception as e:
        return jsonify({'status': 'error', 'message': str(e)}), 500

from shibie import process_image 
from disease_analyzer import DiseaseAnalyzer
disease_analyzer = DiseaseAnalyzer()  # 新增此行

@app.route('/upload', methods=['GET', 'POST'])
def upload():
    if request.method == 'POST':
        # 处理上传文件
        if 'file' not in request.files or 'model' not in request.form:
            return jsonify({'status': 'error', 'message': '未上传文件或未选择模型。'}), 400

        file = request.files['file']
        model_choice = request.form['model']  # 获取所选模型
        if file.filename == '':
            return jsonify({'status': 'error', 'message': '未选择文件。'}), 400

        if file and allowed_file(file.filename):
            # 保存文件
            filename = secure_filename(file.filename)
            file_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
            file.save(file_path)
            
            try:
                # 根据所选模型设置模型路径
                #model_path = os.path.join('./models', model_choice)  # 假设模型存储在模型目录下
                detected_diseases  = process_image(file_path, model_choice)  # 处理图像，不保存结果图像
                print(f"[DEBUG] 检测到的疾病列表: {detected_diseases} (类型: {type(detected_diseases)})")
                analysis_report = disease_analyzer.analyze_diseases(diseases=detected_diseases,
                 model_type=model_choice.split('.')[0]  # 提取模型类型标识
                )
                
                # 返回成功状态和描述信息
                return jsonify({
                    'status': 'success',
                    'message': analysis_report,
                    'result_image_path': os.path.join('./static/uploads/', filename)  # 可以返回处理后的图像路径
                })
            except Exception as e:
                return jsonify({'status': 'error', 'message': f'分析文件时发生错误: {str(e)}'}), 500

        return jsonify({'status': 'error', 'message': '不支持的文件类型。'}), 400

    return render_template('upload.html')  # 渲染文件上传页面



if __name__ == '__main__':
    # 配置日志记录
    logging.basicConfig(
        level=logging.DEBUG,
        format='%(asctime)s %(levelname)s %(message)s',
        handlers=[
            logging.FileHandler("app.log"),
            logging.StreamHandler()
        ]
    )
    app.run(debug=True, host='0.0.0.0', port=5000)
