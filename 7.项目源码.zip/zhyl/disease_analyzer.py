# disease_analyzer.py
import sys
import requests
import json
import re



class DiseaseAnalyzer:
    def __init__(self, server_url='http://192.168.137.122:8080/rkllm_chat/v1/chat/completions', is_streaming=True):
        self.server_url = server_url
        self.is_streaming = is_streaming
        self.session = self._create_session()
        
    def _create_session(self):
        """创建并配置请求会话"""
        session = requests.Session()
        session.keep_alive = False
        adapter = requests.adapters.HTTPAdapter(max_retries=5)
        session.mount('https://', adapter)
        session.mount('http://', adapter)
        return session
    
    def _generate_disease_prompt(self, diseases, model_type):
        """生成疾病分析提示词模板"""
        disease_list = ', '.join(diseases) if diseases else '未检测到明确疾病'
        
        # 根据模型类型定制分析重点
        analysis_focus = {
            'fy': '呼吸系统疾病（如肺炎、结核病）',
            'gj': '妇科疾病（如子宫内膜病变）',
            'nzl': '脑部肿瘤及占位性病变'
        }.get(model_type.lower(), '综合疾病分析')
        
        return f"""
        你现在是三甲医院主任医师，需要分析以下医学影像检测结果：
        
        [影像检测结果]
        {disease_list}
        
        请根据{analysis_focus}专业视角执行：
        1. 临床解读：
           - 疾病名称标准医学解释
           - 典型症状与体征
           - 常见病因及高危因素
        
        2. 诊断建议：
           - 建议补充的检查项目（如CT/MRI/病理）
           - 鉴别诊断要点
        
        3. 治疗方案：
           - 分级诊疗建议（门诊/住院）
           - 首选药物及用法
           - 手术指征说明
        
        4. 预后指导：
           - 疾病发展预测
           - 康复期管理
           - 复发预防措施
        
        格式要求（不需要json格式）：
        [临床诊断]: 核心诊断结论
        [详细分析]: 分点说明病理机制
        [治疗建议]: 分紧急程度列出
        [医学提示]: 相关注意事项
        """
    
    def analyze_diseases(self, diseases, model_type):
        """
        分析检测到的疾病类型
        :param diseases: 疾病名称列表，例如 ["Bacterial Pneumonia"]
        :param model_type: 模型类型标识（如'fy', 'gj', 'nzl'）
        :return: 分析结果字符串
        """
        try:
            if not diseases:
                return "[系统提示] 未检测到明确病理改变，建议定期复查"
            
            prompt = self._generate_disease_prompt(diseases, model_type)
            
            headers = {'Content-Type': 'application/json'}
            data = {
                "model": 'medical_analysis_model',
                "messages": [{"role": "user", "content": prompt}],
                "stream": self.is_streaming
            }

            response = self.session.post(
                self.server_url,
                json=data,
                headers=headers,
                stream=self.is_streaming,
                verify=False,
                timeout=30
            )

            if response.status_code == 200:
                content = self._process_response(response)
                return self._format_content(content)
            else:
                return f"分析服务异常，错误代码：{response.status_code}"

        except requests.exceptions.Timeout:
            return "分析服务响应超时，请稍后重试"
        except Exception as e:
            return f"分析失败：{str(e)}"

    def _process_response(self, response):
        """处理API响应"""
        if not self.is_streaming:
            result = json.loads(response.text)
            return result["choices"][-1]["message"]["content"]
        else:
            full_response = ""
            for line in response.iter_lines():
                if line:
                    decoded_line = line.decode('utf-8')
                    if decoded_line.startswith("data: "):
                        try:
                            line_data = json.loads(decoded_line[6:])
                            full_response += line_data["choices"][-1]["delta"].get("content", "")
                        except:
                            continue
            return full_response

    def _format_content(self, content):
        """格式化输出内容，去除特定标记和无意义内容"""
        # 去除 <think>... 的思考部分（支持多行匹配）
        content = re.sub(r'<think>.*?', '', content, flags=re.DOTALL)
        # 去除多余空行
        content = "\n".join([line.strip() for line in content.splitlines() if line.strip()])
        return content

    def close(self):
        """关闭会话"""
        self.session.close()