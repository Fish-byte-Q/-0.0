# analyzer.py

import sys
import requests
import json
import re  # 导入正则表达式模块

class RKLLMHealthAnalyzer:
    def __init__(self, server_url='http://192.168.137.122:8080/rkllm_chat/v1/chat/completions', is_streaming=True):
        self.server_url = server_url
        self.is_streaming = is_streaming
        self.session = self._create_session()
        
    def _create_session(self):
        """创建并配置请求会话"""
        session = requests.Session()
        session.keep_alive = False
        adapter = requests.adapters.HTTPAdapter(max_retries=5)
        session.mount('https://', adapter)
        session.mount('http://', adapter)
        return session
    
    def _generate_medical_prompt(self, health_data):
        """生成医疗分析提示词模板"""
        return f"""
        你现在是专业的医疗健康分析助手，我将实时提供以下生理参数：
        血氧饱和度：{health_data.get('spo2', '未提供')}%（正常范围95%-100%）
        心率：{health_data.get('heart_rate', '未提供')}次/分钟（正常范围60-100）
        体温：{health_data.get('temperature', '未提供')}℃（正常范围36.5-37.5℃）

        请执行以下任务：
        1. 数据解读：
           - 对比显示测量值与正常范围
           - 标记异常数据（如血氧<94%、心率>100等）
        
        2. 健康评估：
           - 分析各指标间的关联性（如体温升高伴随心率加快）
           - 判断可能原因（如运动后/疾病前兆等）
           - 给出置信度评估（基于临床指南）
        
        3. 个性化建议：
           - 即时行动建议（如"血氧92%建议立即就医"）
           - 长期改善方案（如心率过快建议心肺锻炼）
           - 风险等级评估（低/中/高风险）
        
        4. 设备交互建议：
           - 建议下次监测时间（如2小时后复查体温）
           - 生成简明报告（供医生参考的要点）
    
        请用以下格式回复（注意回复不需要json格式，必须安装我下面的格式就行）：
        [健康状态]:[总体评级]
        [异常指标]：[具体分析]
        [建议]：分紧急程度列出
        [医学提示]：相关科普知识
        """
    
    def analyze_health_data(self, health_data):
        """
        分析健康数据并返回结构化结果
        :param health_data: 包含健康指标的字典，例如：
            {
                "spo2": 98,    # 血氧饱和度
                "heart_rate": 72,  # 心率
                "temperature": 36.7  # 体温
            }
        :return: 分析结果字符串
        """
        try:
            prompt = self._generate_medical_prompt(health_data)
            
            headers = {
                'Content-Type': 'application/json',
                'Authorization': 'not_required'
            }

            data = {
                "model": 'medical_analysis_model',
                "messages": [{"role": "user", "content": prompt}],
                "stream": self.is_streaming
            }

            response = self.session.post(
                self.server_url,
                json=data,
                headers=headers,
                stream=self.is_streaming,
                verify=False
            )

            if response.status_code == 200:
                if not self.is_streaming:
                    result = json.loads(response.text)
                    content = result["choices"][-1]["message"]["content"]
                else:
                    full_response = ""
                    for line in response.iter_lines():
                        if line:
                            decoded_line = line.decode('utf-8')
                            if decoded_line.startswith("data: "):
                                try:
                                    line_data = json.loads(decoded_line[6:])
                                    if 'choices' in line_data:
                                        content = line_data["choices"][-1]["delta"].get("content", "")
                                        full_response += content
                                        sys.stdout.flush()
                                except json.JSONDecodeError:
                                    continue
                    content = full_response

                # 移除 <think> 标签及其内容
                content = re.sub(r'<think>.*?</think>', '', content, flags=re.DOTALL)
                
                # 去除可能存在的多余空行
                content = "\n".join([line.strip() for line in content.splitlines() if line.strip()])

                return content
            else:
                return f"Error: {response.text}"

        except Exception as e:
            return f"Analysis failed: {str(e)}"

    def close(self):
        """关闭会话"""
        self.session.close()
